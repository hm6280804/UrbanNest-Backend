<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Host Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-emerald-50 font-sans">
    <nav class="bg-emerald-600 p-4 text-white flex justify-between items-center shadow-md">
        <h1 class="text-xl font-bold">UrbanNest Host Console</h1>
        <div class="flex items-center gap-4">
            <span>Hello, <strong><?php echo e(Auth::user()->name); ?></strong> (Host)</span>
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="bg-emerald-800 px-3 py-1 rounded text-sm hover:bg-emerald-900">Logout</button>
            </form>
        </div>
    </nav>
    <main class="p-8 max-w-4xl mx-auto">
        <div class="bg-white p-6 rounded-lg shadow">
            <h2 class="text-2xl font-bold text-emerald-800 mb-2">Property Management Portal</h2>
            <p class="text-slate-600">Welcome to your listing headquarters. Use this control center to publish new spaces, handle inbound booking reservations, and optimize your hosting analytics.</p>
        </div>
    </main>
</body>
</html><?php /**PATH D:\Software_Development\laravel_Projects\multi_user_system\resources\views/dashboards/host.blade.php ENDPATH**/ ?>