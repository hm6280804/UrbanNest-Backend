<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-blue-50 font-sans">
    <nav class="bg-blue-600 p-4 text-white flex justify-between items-center shadow-md">
        <h1 class="text-xl font-bold">UrbanNest Tenant Panel</h1>
        <div class="flex items-center gap-4">
            <span>Hello, <strong><?php echo e(Auth::user()->name); ?></strong> (Tenant)</span>
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="bg-blue-800 px-3 py-1 rounded text-sm hover:bg-blue-900">Logout</button>
            </form>
        </div>
    </nav>
    <main class="p-8 max-w-4xl mx-auto">
        <div class="bg-white p-6 rounded-lg shadow">
            <h2 class="text-2xl font-bold text-blue-800 mb-2">Explore Available Rentals</h2>
            <p class="text-slate-600">Welcome to your personal marketplace portal. Here you can browse active listings, message property hosts, and track your reservation history.</p>
        </div>
    </main>
</body>
</html><?php /**PATH D:\Software_Development\laravel_Projects\multi_user_system\resources\views/dashboards/user.blade.php ENDPATH**/ ?>