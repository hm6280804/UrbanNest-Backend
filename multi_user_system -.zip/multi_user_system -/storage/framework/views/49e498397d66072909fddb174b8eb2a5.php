<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-slate-100 flex items-center justify-center h-screen">
    <div class="bg-white p-8 rounded-lg shadow-md w-96">
        <h2 class="text-2xl font-bold mb-6 text-center text-slate-800">Welcome Back</h2>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 text-red-600 p-3 rounded mb-4 text-sm">
                <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($error); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label class="block text-sm font-semibold text-slate-600 mb-1">Email Address</label>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="w-full border p-2 rounded focus:outline-slate-400" required>
            </div>
            <div class="mb-6">
                <label class="block text-sm font-semibold text-slate-600 mb-1">Password</label>
                <input type="password" name="password" class="w-full border p-2 rounded focus:outline-slate-400" required>
            </div>
            <button type="submit" class="w-full bg-slate-800 text-white p-2 rounded font-bold hover:bg-slate-900">Log In</button>
        </form>
        <p class="text-sm text-center mt-4 text-slate-500">Need an account? <a href="<?php echo e(route('register')); ?>" class="text-blue-600 hover:underline">Sign up</a></p>
    </div>
</body>
</html><?php /**PATH D:\Software_Development\laravel_Projects\multi_user_system\resources\views/auth/login.blade.php ENDPATH**/ ?>