<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-purple-50 font-sans">
    <nav class="bg-purple-900 p-4 text-white flex justify-between items-center shadow-md">
        <h1 class="text-xl font-bold">UrbanNest Master Admin System</h1>
        <div class="flex items-center gap-4">
            <span>System God-Mode: <strong>{{ Auth::user()->name }}</strong></span>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="bg-purple-700 px-3 py-1 rounded text-sm hover:bg-purple-800">Logout</button>
            </form>
        </div>
    </nav>
    <main class="p-8 max-w-4xl mx-auto">
        <div class="bg-white p-6 rounded-lg shadow border-l-4 border-purple-600">
            <h2 class="text-2xl font-bold text-purple-950 mb-2">Global Platform Metrics</h2>
            <p class="text-slate-600 mb-4">This section allows you to manage system users, oversee security audit reports, handle payout flags, and modify dynamic platform configuration schemas.</p>
            <span class="inline-block bg-purple-100 text-purple-800 text-xs font-semibold px-2.5 py-0.5 rounded">High Privileges Active</span>
        </div>
    </main>
</body>
</html>