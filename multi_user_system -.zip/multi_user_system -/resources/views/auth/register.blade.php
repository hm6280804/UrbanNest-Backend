<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-slate-100 flex items-center justify-center h-screen">
    <div class="bg-white p-8 rounded-lg shadow-md w-96">
        <h2 class="text-2xl font-bold mb-6 text-center text-slate-800">Create an Account</h2>
        
        @if ($errors->any())
            <div class="bg-red-100 text-red-600 p-3 rounded mb-4 text-sm">
                <ul>@foreach ($errors->all() as $error) <li>{{ $error }}</li> @endforeach</ul>
            </div>
        @endif

        <form action="{{ route('register') }}" method="POST">
            @csrf
            <div class="mb-4">
                <label class="block text-sm font-semibold text-slate-600 mb-1">Full Name</label>
                <input type="text" name="name" value="{{ old('name') }}" class="w-full border p-2 rounded focus:outline-slate-400" required>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-semibold text-slate-600 mb-1">Email Address</label>
                <input type="email" name="email" value="{{ old('email') }}" class="w-full border p-2 rounded focus:outline-slate-400" required>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-semibold text-slate-600 mb-1">Register As</label>
                <select name="role" class="w-full border p-2 rounded bg-white focus:outline-slate-400" required>
                    <option value="user" {{ old('role') == 'user' ? 'selected' : '' }}>Regular User (Tenant)</option>
                    <option value="host" {{ old('role') == 'host' ? 'selected' : '' }}>Host / Property Owner</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-semibold text-slate-600 mb-1">Password</label>
                <input type="password" name="password" class="w-full border p-2 rounded focus:outline-slate-400" required>
            </div>
            <div class="mb-6">
                <label class="block text-sm font-semibold text-slate-600 mb-1">Confirm Password</label>
                <input type="password" name="password_confirmation" class="w-full border p-2 rounded focus:outline-slate-400" required>
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white p-2 rounded font-bold hover:bg-blue-700">Sign Up</button>
        </form>
        <p class="text-sm text-center mt-4 text-slate-500">Already have an account? <a href="{{ route('login') }}" class="text-blue-600 hover:underline">Log in</a></p>
    </div>
</body>
</html>