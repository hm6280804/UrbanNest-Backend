<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('welcome');
// });

// Guest Routes (Login / Registration)
Route::middleware('guest')->group(function () {
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
    
    // CHANGE THIS: Move the login name and path to '/login'
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    
    // OPTIONAL: Redirect anyone who visits the bare domain '/' straight to the login page
    Route::get('/', function () {
        return redirect()->route('login');
    });
});

// Logout Route
Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// Protected Dashboard Routes
Route::middleware('auth')->group(function () {
    
    Route::get('/dashboard', [DashboardController::class, 'userDashboard'])
        ->middleware('role:user')
        ->name('user.dashboard');

    Route::get('/host/dashboard', [DashboardController::class, 'hostDashboard'])
        ->middleware('role:host')
        ->name('host.dashboard');

    Route::get('/admin/dashboard', [DashboardController::class, 'adminDashboard'])
        ->middleware('role:admin')
        ->name('admin.dashboard');
});
