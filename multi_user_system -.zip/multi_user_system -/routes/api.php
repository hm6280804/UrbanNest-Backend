<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\BookingController;
use App\Http\Controllers\Api\ListingController;
use App\Http\Controllers\Api\WebhookController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Public API Routes
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

// Protected API Routes (Requires valid Bearer Token)
Route::middleware('auth:sanctum')->group(function () {
    
    Route::post('/logout', [AuthController::class, 'logout']);
    
    // A quick route to check who is currently authenticated
    Route::get('/me', function (Request $request) {
        return response()->json($request->user());
    });

    // Only users authenticated AND explicitly possessing the 'host' role can cross this boundary
    Route::middleware('auth.api.role:host')->group(function () {
        Route::post('/listings', [ListingController::class, 'store']);
    });

    // Only standard tenants or hosts can issue bookings
    Route::post('/bookings', [BookingController::class, 'store']);
});


// Public Marketplace Discovery Routes
Route::get('/listings', [ListingController::class, 'index']);
Route::get('/listings/{listing}', [ListingController::class, 'show']);

// Public Webhook Inbound Endpoint (Unprotected)
Route::post('/webhooks/stripe', [WebhookController::class, 'handleStripe']);