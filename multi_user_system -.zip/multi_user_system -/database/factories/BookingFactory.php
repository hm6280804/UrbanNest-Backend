<?php

namespace Database\Factories;

use App\Models\Booking;
use App\Models\Listing;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Booking>
 */
class BookingFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'user_id' => User::factory(),
            'listing_id' => Listing::factory(), // Generates a listing automatically if missing
            'total_price' => $this->faker->numberBetween(5000, 30000),
            'status' => 'pending',
            'stripe_session_id' => 'cs_test_' . \Illuminate\Support\Str::random(24),
        ];
    }
}
