<?php

namespace Tests\Feature;

use App\Events\PaymentSucceeded;
use App\Models\Booking;
use App\Models\Listing;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Event;
use Tests\TestCase;

class BookingApiTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function an_authenticated_user_can_initiate_a_booking()
    {
        $tenant = User::factory()->create(['role' => 'user']);
        $listing = Listing::factory()->create(['price_per_night' => 10000]); // $100

        $response = $this->actingAs($tenant, 'sanctum')->postJson('/api/bookings', [
            'listing_id' => $listing->id,
            'nights' => 3,
        ]);

        $response->assertStatus(201);
        $response->assertJsonFragment(['status' => 'pending', 'total_price' => 30000]);
        $this->assertDatabaseHas('bookings', ['user_id' => $tenant->id, 'total_price' => 30000]);
    }

    /** @test */
    public function a_successful_stripe_webhook_payload_updates_booking_and_fires_event()
    {
        // Stop actual events from executing listeners so our logs stay clean during tests
        Event::fake();

        $tenant = User::factory()->create();
        $booking = Booking::factory()->create([
            'user_id' => $tenant->id,
            'status' => 'pending',
            'stripe_session_id' => 'cs_test_mock_123'
        ]);

        // Construct mock payload matching standard Stripe structured webhooks
        $webhookPayload = [
            'type' => 'checkout.session.completed',
            'data' => [
                'object' => [
                    'id' => 'cs_test_mock_123'
                ]
            ]
        ];

        $response = $this->postJson('/api/webhooks/stripe', $webhookPayload);

        $response->assertStatus(200);
        
        // Assert the target database column successfully updated state
        $this->assertDatabaseHas('bookings', [
            'id' => $booking->id,
            'status' => 'paid'
        ]);

        // Verify that the specific event was fired asynchronously
        Event::assertDispatched(PaymentSucceeded::class, function ($event) use ($booking) {
            return $event->booking->id === $booking->id;
        });
    }
}