<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AuthApiTest extends TestCase
{
    use RefreshDatabase; // Resets the database after every single test

    /** @test */
    public function a_user_can_register_successfully_via_the_api()
    {
        $response = $this->postJson('/api/register', [
            'name' => 'John Doe',
            'email' => 'john@example.com',
            'password' => 'password123',
            'role' => 'user',
        ]);

        // Assert HTTP status code is 201 Created
        $response->assertStatus(201);

        // Assert the JSON response contains an access token
        $response->assertJsonStructure([
            'message',
            'access_token',
            'token_type',
            'user' => ['id', 'name', 'email', 'role']
        ]);

        // Assert the user actually exists in the database
        $this->assertDatabaseHas('users', [
            'email' => 'john@example.com',
            'role' => 'user',
        ]);
    }

    /** @test */
    public function registration_fails_if_required_fields_are_missing()
    {
        $response = $this->postJson('/api/register', [
            'name' => '', // Empty name
            'email' => 'not-an-email', // Bad email
            'password' => 'short', // Too short
            'role' => 'admin', // Role logic should block this
        ]);

        // Assert validation failed (Unprocessable Entity)
        $response->assertStatus(422);
        $response->assertJsonValidationErrors(['name', 'email', 'password', 'role']);
    }

    /** @test */
    public function an_existing_user_can_login_and_receive_a_sanctum_token()
    {
        // Arrange: Create a user inside our isolated testing database
        $user = User::factory()->create([
            'email' => 'host@urbannest.com',
            'password' => bcrypt('secret123'),
            'role' => 'host',
        ]);

        // Act: Hit the login API endpoint
        $response = $this->postJson('/api/login', [
            'email' => 'host@urbannest.com',
            'password' => 'secret123',
        ]);

        // Assert: Login was successful
        $response->assertStatus(200);
        $response->assertJsonStructure(['access_token', 'token_type', 'message']);
    }

    /** @test */
    public function login_fails_with_incorrect_credentials()
    {
        $user = User::factory()->create([
            'email' => 'tenant@urbannest.com',
            'password' => bcrypt('secret123'),
        ]);

        $response = $this->postJson('/api/login', [
            'email' => 'tenant@urbannest.com',
            'password' => 'wrong-password',
        ]);

        // Assert HTTP status code is 401 Unauthorized
        $response->assertStatus(401);
        $response->assertJson([
            'message' => 'Invalid login credentials'
        ]);
    }

    /** @test */
    public function an_unauthenticated_user_cannot_access_the_me_endpoint()
    {
        // Try hitting a route wrapped in auth:sanctum middleware without passing a token
        $response = $this->getJson('/api/me');

        // Assert access is denied
        $response->assertStatus(401);
    }

    /** @test */
    public function an_authenticated_user_can_access_the_me_endpoint_with_a_bearer_token()
    {
        $user = User::factory()->create();

        // ActingAs simulates passing the Sanctum Bearer token automatically
        $response = $this->actingAs($user, 'sanctum')->getJson('/api/me');

        $response->assertStatus(200);
        $response->assertJson([
            'email' => $user->email,
        ]);
    }
}