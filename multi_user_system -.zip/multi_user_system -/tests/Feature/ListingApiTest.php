<?php

namespace Tests\Feature;

use App\Models\Listing;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ListingApiTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function anyone_can_view_the_listings_index()
    {
        $host = User::factory()->create(['role' => 'host']);
        Listing::factory()->create(['user_id' => $host->id, 'is_active' => true, 'title' => 'Cozy Flat']);

        $response = $this->getJson('/api/listings');

        $response->assertStatus(200);
        $response->assertJsonCount(1, 'listings');
        $response->assertJsonFragment(['title' => 'Cozy Flat']);
    }

    /** @test */
    public function an_authenticated_host_can_create_a_listing()
    {
        $host = User::factory()->create(['role' => 'host']);

        $response = $this->actingAs($host, 'sanctum')->postJson('/api/listings', [
            'title' => 'Luxury Beachfront Villa',
            'description' => 'Beautiful panoramic ocean view penthouse.',
            'price_per_night' => 15000, // $150.00 represented as cents
        ]);

        $response->assertStatus(201);
        $this->assertDatabaseHas('listings', ['title' => 'Luxury Beachfront Villa']);
    }

    /** @test */
    public function a_standard_user_cannot_create_a_listing()
    {
        $tenant = User::factory()->create(['role' => 'user']); // Explicitly 'user' role

        $response = $this->actingAs($tenant, 'sanctum')->postJson('/api/listings', [
            'title' => 'Illegal Listing Creation Attempt',
            'description' => 'Should fail due to security permissions middleware.',
            'price_per_night' => 5000,
        ]);

        // Expect Forbidden Status Code from our new custom ApiRoleMiddleware
        $response->assertStatus(403);
        $this->assertDatabaseMissing('listings', ['title' => 'Illegal Listing Creation Attempt']);
    }
}