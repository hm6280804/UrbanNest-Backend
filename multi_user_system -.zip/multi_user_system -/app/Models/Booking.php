<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    /** @use HasFactory<\Database\Factories\BookingFactory> */
    use HasFactory;

    // Ensure 'listing_id' and the other attributes are explicitly allowed here:
    protected $fillable = [
        'user_id', 
        'listing_id', 
        'total_price', 
        'status', 
        'stripe_session_id'
    ];

    public function tenant(){
        return $this->belongsTo(User::class, 'user_id');
    }

    public function listing(){
        return $this->belongsTo(Listing::class);
    }
}
