<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Listing extends Model
{
    /** @use HasFactory<\Database\Factories\ListingFactory> */
    use HasFactory;

    protected $fillable = ['title', 'description', 'price_per_night', 'is_active'];

    public function host(){
        return $this->belongsTo(User::class, 'user_id');
    }
}
