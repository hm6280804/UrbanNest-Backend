<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class RoleMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  Closure(Request): (Response)  $next
     */
    public function handle(Request $request, Closure $next, string $role): Response
    {
        // 1. Check if the user is logged in
        if(!Auth::check()){
            return redirect()->route('login');
        }

        // 2. Check if the logged-in user has the required role
        if(Auth::user()->role !== $role){
            abort(403, 'Unauthorized access to this dashboard');
        }
        
        return $next($request);
    }
}
