<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ApiRoleMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  Closure(Request): (Response)  $next
     */
    public function handle(Request $request, Closure $next, string $role): Response
    {
        // Check if the authenticated user has the required role
        if(!$request->user() || $request->user()->role !== $role){
            return response()->json([
                'message' => 'Access denied. This action requires the ' . $role . ' role.'
            ], 403); // 403 Forbidden
        }
        return $next($request);
    }
}
