<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function userDashboard() { return view('dashboards.user'); }
    public function hostDashboard() { return view('dashboards.host'); }
    public function adminDashboard() { return view('dashboards.admin'); }
}
