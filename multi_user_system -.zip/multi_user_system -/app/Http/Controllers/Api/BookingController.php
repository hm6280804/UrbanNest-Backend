<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Listing;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class BookingController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'listing_id' => 'required|exists:listings,id',
            'nights' => 'required|integer|min:1',
        ]);

        $listing = Listing::findOrFail($request->listing_id);
        $totalPrice = $listing->price_per_night * $request->nights;
        $mockStripeSessionId = 'cs_test_' . Str::random(24);

        $booking = $request->user()->bookings()->create([
            'listing_id' => $listing->id,
            'total_price' => $totalPrice,
            'status' => 'pending',
            'stripe_session_id' => $mockStripeSessionId,
        ]);

        return response()->json([
            'message' => 'Booking initiated successfully. Complete payment via the simulated redirect checkout URL.',
            'booking' => $booking,
            'mock_stripe_checkout_url' => "https://checkout.stripe.com/pay/{$mockStripeSessionId}"
        ], 201);
    }
}
