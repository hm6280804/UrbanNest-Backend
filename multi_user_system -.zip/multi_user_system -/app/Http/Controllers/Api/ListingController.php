<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Listing;
use Illuminate\Http\Request;

class ListingController extends Controller
{
    // Public: View all active listings
    public function index()
    {
        $listings = Listing::where('is_active', true)->with('host:id,name,email')->latest()->get();

        return response()->json([
            'listings' => $listings
        ], 200);
    }

    // Protected: Hosts create listings
    public function store(Request $request)
    {
        $fields = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'price_per_night' => 'required|integer|min:100', // min $1.00 expressed as 100 cents
        ]);

        // Create the listing directly through the authenticated user's relationship model
        $listing = $request->user()->listings()->create($fields);

        return response()->json([
            'message' => 'Listing created successfully',
            'listing' => $listing->load('host:id,name')
        ], 201);
    }

    // Public: View a single listing
    public function show(Listing $listing)
    {
        if (!$listing->is_active) {
            return response()->json(['message' => 'Listing not found or inactive.'], 404);
        }

        return response()->json([
            'listing' => $listing->load('host:id,name,email')
        ], 200);
    }
}