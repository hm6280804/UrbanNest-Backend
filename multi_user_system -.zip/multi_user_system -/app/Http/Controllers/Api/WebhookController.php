<?php

namespace App\Http\Controllers\Api;

use App\Events\PaymentSucceeded;
use App\Http\Controllers\Controller;
use App\Models\Booking;
use Illuminate\Http\Request;

class WebhookController extends Controller
{
    public function handleStripe(Request $request)
    {
        // Real webhooks require signature verification via the Stripe SDK.
        // For our test workspace simulation, we parse the structural payload directly.
        $payload = $request->all();

        if ($payload['type'] === 'checkout.session.completed') {
            $sessionId = $payload['data']['object']['id'];

            $booking = Booking::where('stripe_session_id', $sessionId)->first();

            if ($booking && $booking->status === 'pending') {
                $booking->update(['status' => 'paid']);

                // Trigger the Event! This throws the background job into the queue
                event(new PaymentSucceeded($booking));
            }
        }

        return response()->json(['received' => true], 200);
    }
}