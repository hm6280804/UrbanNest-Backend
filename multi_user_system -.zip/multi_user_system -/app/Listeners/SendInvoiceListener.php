<?php

namespace App\Listeners;

use App\Events\PaymentSucceeded;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;

class SendInvoiceListener
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(PaymentSucceeded $event): void
    {
        $booking = $event->booking;

        Log::info("Asynchronous Queue Triggered: Invoice sent to tenant {$booking->tenant->email} for Booking ID #{$booking->id}. Total Processed: " . ($booking->total_price / 100) . " USD.");

    }
}
