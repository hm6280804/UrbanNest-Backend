<?php

namespace App\Console\Commands;

use App\Models\Booking;
use Carbon\Carbon;
use Illuminate\Console\Command;

class CancelStaleBookings extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:cancel-stale-bookings';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cancel pending bookings that have been unpaid for over 24 hours.';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('Starting cleanup of stale bookings...');

        // Find bookings still 'pending' after 24 hours
        $threshold = Carbon::now()->subHours(24);

        $staleBookingsCount = Booking::where('status', 'pending')
            ->where('created_at', '<=', $threshold)
            ->update(['status' => 'expired']);

        $this->info("Successfully expired {$staleBookingsCount} stale booking(s).");

        return Command::SUCCESS;
    }
}
